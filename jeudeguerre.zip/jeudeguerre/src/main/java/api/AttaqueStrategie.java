package api;

public interface AttaqueStrategie {
    public void attaque();
}
