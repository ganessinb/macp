package api;

public class Rouler implements DeplacementStrategie{
    @Override
    public void seDeplacer() {
        System.out.println("Je roule");
    }
}
