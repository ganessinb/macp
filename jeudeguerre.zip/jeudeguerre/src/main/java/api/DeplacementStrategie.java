package api;

public interface DeplacementStrategie {
    public void seDeplacer();
}
